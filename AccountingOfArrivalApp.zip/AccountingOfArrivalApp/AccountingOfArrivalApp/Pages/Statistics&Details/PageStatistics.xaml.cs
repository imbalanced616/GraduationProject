﻿using AccountingOfArrivalApp.Classes;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms.DataVisualization.Charting;

namespace AccountingOfArrivalApp.Pages.Statistics_Details
{
    /// <summary>
    /// Логика взаимодействия для PageStatistics.xaml
    /// </summary>
    public partial class PageStatistics : Page
    {
        public PageStatistics()
        {
            InitializeComponent();

            cmbYear.ItemsSource = GetYears();
            cmbYear.SelectedIndex = 0;

            chartArrivals.ChartAreas[0].AxisY.Title = "Поступления";
            chartArrivals.ChartAreas[0].AxisX.TitleFont = new Font("Segoe UI", 12);
            chartArrivals.ChartAreas[0].AxisY.TitleFont = new Font("Segoe UI", 12);
            chartArrivals.ChartAreas[0].AxisX.LabelStyle.Font = new Font("Segoe UI", 12);
            chartArrivals.ChartAreas[0].AxisY.LabelStyle.Font = new Font("Segoe UI", 12);
        }

        public void ChartInitialization()
        {
            int reportType;
            if (rbQuarter.IsChecked == true) reportType = 0;
            else if (rbMonth.IsChecked == true) reportType = 1;
            else reportType = 2;
            int year = int.Parse(cmbYear.SelectedItem.ToString());
            SeriesChartType chartType;
            if ((bool)rbColumn.IsChecked) chartType = SeriesChartType.Column;
            else if ((bool)rbBar.IsChecked) chartType = SeriesChartType.Bar;
            else if ((bool)rbPie.IsChecked) chartType = SeriesChartType.Pie;
            else chartType = SeriesChartType.Line;
            int accountingInStatistics;
            if ((bool)rbQuantity.IsChecked) accountingInStatistics = 1;
            else accountingInStatistics = 2;
            CreatingСhart((bool)cbArrivalsSeparation.IsChecked, reportType, year, chartType, accountingInStatistics);
            CreatingChartTitle();
            ShowValues_Click(null, null);
            BackColor_Click(null, null);
            chartArrivals.ChartAreas[0].AxisY.Interval = double.Parse(txbStepIntervalArrivals.Text);
        }

        public void CreatingChartTitle()
        {
            string accounting = rbQuantity.IsChecked == true ? "количества поступлений" : "затрат на поступления";
            string title = $"Диаграмма {accounting}\n";
            if (rbQuarter.IsChecked == true) title += "по кварталам за " + cmbYear.SelectedItem.ToString() + " год";
            else if (rbMonth.IsChecked == true) title += "по месяцам за " + cmbYear.SelectedItem.ToString() + " год";
            else title += "по годам";
            txbChartTitle.Text = title;
            TxbChartTitle_TextChanged(null, null);
        }

        public List<int> GetYears()
        {
            List<int> Years = new List<int>();
            foreach (InvoicesOnArrival invoice in InvoicesOnArrival.ToList()) Years.Add(((DateTime)invoice.DeliveryDate).Year);
            return Years.Distinct().OrderBy(x => x).ToList();
        }

        public void CreatingСhart(bool arrivalsSeparation, int reportType, int year, SeriesChartType chartType, int accountingInStatistics)
        {
            chartArrivals.Series.Clear();
            chartArrivals.Legends.Clear();
            if (arrivalsSeparation)
            {
                chartArrivals.Series.Add(new Series() { Font = new Font("Segoe UI", 12) });
                chartArrivals.Series.Add(new Series() { Font = new Font("Segoe UI", 12) });
                chartArrivals.Series[0].Name = "Распределенные";
                chartArrivals.Series[1].Name = "Нераспределенные";
                chartArrivals.Legends.Add(new Legend()
                {
                    Title = "Виды поступлений",
                    Font = new Font("Segoe UI", 9),
                    TitleFont = new Font("Segoe UI", 10, System.Drawing.FontStyle.Bold),
                    Docking = Docking.Top,
                    Alignment = StringAlignment.Center
                });
                if (reportType == 0)
                {
                    List<InvoicesOnArrival> list = InvoicesOnArrival.ToList().Where(x => ((DateTime)x.DeliveryDate).Year == year).ToList();
                    double[] Quarters = new double[] { 0, 0, 0, 0 };
                    double[] Quarters2 = new double[] { 0, 0, 0, 0 };
                    string[] QuartersStr = new string[] { "I", "II", "III", "IV" };
                    foreach (InvoicesOnArrival invoice in list)
                    {
                        if ((bool)invoice.DistributedInvoice)
                        {
                            if (accountingInStatistics == 1)
                            {
                                if (invoice.DeliveryDate >= new DateTime(year, 1, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 3, 31, 0, 0, 0)) Quarters[0]++;
                                else if (invoice.DeliveryDate >= new DateTime(year, 4, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 6, 30, 0, 0, 0)) Quarters[1]++;
                                else if (invoice.DeliveryDate >= new DateTime(year, 7, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 9, 30, 0, 0, 0)) Quarters[2]++;
                                else if (invoice.DeliveryDate >= new DateTime(year, 10, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 12, 31, 0, 0, 0)) Quarters[3]++;
                            }
                            else
                            {
                                if (invoice.DeliveryDate >= new DateTime(year, 1, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 3, 31, 0, 0, 0)) Quarters[0] += invoice.AmountInThousands;
                                else if (invoice.DeliveryDate >= new DateTime(year, 4, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 6, 30, 0, 0, 0)) Quarters[1] += invoice.AmountInThousands;
                                else if (invoice.DeliveryDate >= new DateTime(year, 7, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 9, 30, 0, 0, 0)) Quarters[2] += invoice.AmountInThousands;
                                else if (invoice.DeliveryDate >= new DateTime(year, 10, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 12, 31, 0, 0, 0)) Quarters[3] += invoice.AmountInThousands;
                            }
                        }
                        else
                        {
                            if (accountingInStatistics == 1)
                            {
                                if (invoice.DeliveryDate >= new DateTime(year, 1, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 3, 31, 0, 0, 0)) Quarters2[0]++;
                                else if (invoice.DeliveryDate >= new DateTime(year, 4, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 6, 30, 0, 0, 0)) Quarters2[1]++;
                                else if (invoice.DeliveryDate >= new DateTime(year, 7, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 9, 30, 0, 0, 0)) Quarters2[2]++;
                                else if (invoice.DeliveryDate >= new DateTime(year, 10, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 12, 31, 0, 0, 0)) Quarters2[3]++;
                            }
                            else
                            {
                                if (invoice.DeliveryDate >= new DateTime(year, 1, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 3, 31, 0, 0, 0)) Quarters2[0] += invoice.AmountInThousands;
                                else if (invoice.DeliveryDate >= new DateTime(year, 4, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 6, 30, 0, 0, 0)) Quarters2[1] += invoice.AmountInThousands;
                                else if (invoice.DeliveryDate >= new DateTime(year, 7, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 9, 30, 0, 0, 0)) Quarters2[2] += invoice.AmountInThousands;
                                else if (invoice.DeliveryDate >= new DateTime(year, 10, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 12, 31, 0, 0, 0)) Quarters2[3] += invoice.AmountInThousands;
                            }
                        }
                    }
                    for (int i = 0; i < QuartersStr.Length; i++)
                    {
                        chartArrivals.Series[0].Points.Add(Quarters[i]).AxisLabel = QuartersStr[i];
                        chartArrivals.Series[1].Points.Add(Quarters2[i]).AxisLabel = QuartersStr[i];
                    }
                    chartArrivals.ChartAreas[0].AxisX.Title = "Кварталы";
                }
                else if (reportType == 1)
                {
                    List<InvoicesOnArrival> list = InvoicesOnArrival.ToList().Where(x => ((DateTime)x.DeliveryDate).Year == year).ToList();
                    double[] Months = new double[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
                    double[] Months2 = new double[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
                    foreach (InvoicesOnArrival invoice in list)
                    {
                        int Month = ((DateTime)invoice.DeliveryDate).Month;
                        if (accountingInStatistics == 1)
                        {
                            if ((bool)invoice.DistributedInvoice) Months[Month - 1]++;
                            else Months2[Month - 1]++;
                        }
                        else
                        {
                            if ((bool)invoice.DistributedInvoice) Months[Month - 1] += invoice.AmountInThousands;
                            else Months2[Month - 1] += invoice.AmountInThousands;
                        }
                    }
                    for (int i = 0; i < Months.Length; i++)
                    {
                        chartArrivals.Series[0].Points.Add(Months[i]).AxisLabel = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(i + 1);
                        chartArrivals.Series[1].Points.Add(Months2[i]).AxisLabel = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(i + 1);
                    }
                    chartArrivals.ChartAreas[0].AxisX.Title = "Месяцы";
                }
                else
                {
                    foreach (int y in GetYears())
                    {
                        if(accountingInStatistics == 1)
                        {
                            chartArrivals.Series[0].Points.Add(InvoicesOnArrival.ToList().Where(x => ((DateTime)x.DeliveryDate).Year == y && x.DistributedInvoice == false).ToList().Count()).AxisLabel = y.ToString() + " г.";
                            chartArrivals.Series[1].Points.Add(InvoicesOnArrival.ToList().Where(x => ((DateTime)x.DeliveryDate).Year == y && x.DistributedInvoice == true).ToList().Count()).AxisLabel = y.ToString() + " г.";
                        }
                        else
                        {
                            chartArrivals.Series[0].Points.Add(InvoicesOnArrival.ToList().Where(x => ((DateTime)x.DeliveryDate).Year == y && x.DistributedInvoice == false).ToList().Sum(x => x.AmountInThousands)).AxisLabel = y.ToString() + " г.";
                            chartArrivals.Series[1].Points.Add(InvoicesOnArrival.ToList().Where(x => ((DateTime)x.DeliveryDate).Year == y && x.DistributedInvoice == true).ToList().Sum(x => x.AmountInThousands)).AxisLabel = y.ToString() + " г.";
                        }
                    }
                    chartArrivals.ChartAreas[0].AxisX.Title = "Года";
                }
            }
            else
            {
                chartArrivals.Series.Add(new Series() { Font = new Font("Segoe UI", 12) });
                if (reportType == 0)
                {
                    List<InvoicesOnArrival> list = InvoicesOnArrival.ToList().Where(x => ((DateTime)x.DeliveryDate).Year == year).ToList();
                    double[] Quarters = new double[] { 0, 0, 0, 0 };
                    foreach (InvoicesOnArrival invoice in list)
                    {
                        if (accountingInStatistics == 1)
                        {
                            if (invoice.DeliveryDate >= new DateTime(year, 1, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 3, 31, 0, 0, 0)) Quarters[0]++;
                            else if (invoice.DeliveryDate >= new DateTime(year, 4, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 6, 30, 0, 0, 0)) Quarters[1]++;
                            else if (invoice.DeliveryDate >= new DateTime(year, 7, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 9, 30, 0, 0, 0)) Quarters[2]++;
                            else if (invoice.DeliveryDate >= new DateTime(year, 10, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 12, 31, 0, 0, 0)) Quarters[3]++;
                        }
                        else
                        {
                            if (invoice.DeliveryDate >= new DateTime(year, 1, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 3, 31, 0, 0, 0)) Quarters[0] += invoice.AmountInThousands;
                            else if (invoice.DeliveryDate >= new DateTime(year, 4, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 6, 30, 0, 0, 0)) Quarters[1] += invoice.AmountInThousands;
                            else if (invoice.DeliveryDate >= new DateTime(year, 7, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 9, 30, 0, 0, 0)) Quarters[2] += invoice.AmountInThousands;
                            else if (invoice.DeliveryDate >= new DateTime(year, 10, 1, 0, 0, 0) && invoice.DeliveryDate < new DateTime(year, 12, 31, 0, 0, 0)) Quarters[3] += invoice.AmountInThousands;
                        }
                    }
                    chartArrivals.Series[0].Points.Add(Quarters[0]).AxisLabel = "I";
                    chartArrivals.Series[0].Points.Add(Quarters[1]).AxisLabel = "II";
                    chartArrivals.Series[0].Points.Add(Quarters[2]).AxisLabel = "III";
                    chartArrivals.Series[0].Points.Add(Quarters[3]).AxisLabel = "IV";
                    chartArrivals.ChartAreas[0].AxisX.Title = "Кварталы";
                }
                else if (reportType == 1)
                {
                    List<InvoicesOnArrival> list = InvoicesOnArrival.ToList().Where(x => ((DateTime)x.DeliveryDate).Year == year).ToList();
                    double[] Months = new double[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
                    foreach (InvoicesOnArrival invoice in list)
                    {
                        int Month = ((DateTime)invoice.DeliveryDate).Month;
                        if (accountingInStatistics == 1) Months[Month - 1]++;
                        else Months[Month - 1] += invoice.AmountInThousands;
                    }
                    for (int i = 0; i < Months.Length; i++) chartArrivals.Series[0].Points.Add(Months[i]).AxisLabel = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(i + 1);
                    chartArrivals.ChartAreas[0].AxisX.Title = "Месяцы";
                }
                else
                {
                    if (accountingInStatistics == 1) foreach (int y in GetYears()) chartArrivals.Series[0].Points.Add(InvoicesOnArrival.ToList().Where(x => ((DateTime)x.DeliveryDate).Year == y).ToList().Count()).AxisLabel = y.ToString() + " г.";
                    else foreach (int y in GetYears()) chartArrivals.Series[0].Points.Add(InvoicesOnArrival.ToList().Where(x => ((DateTime)x.DeliveryDate).Year == y).ToList().Sum(x => x.AmountInThousands)).AxisLabel = y.ToString() + " г.";
                    chartArrivals.ChartAreas[0].AxisX.Title = "Года";
                }
            }
            foreach (Series s in chartArrivals.Series)
            {
                s.ChartType = chartType;
                s.BorderWidth = 5;
            }
            chartArrivals.ChartAreas[0].AxisX.Interval = 1;
            if (chartType == SeriesChartType.Pie)
            {
                if (arrivalsSeparation) chartArrivals.Legends[0].Title = chartArrivals.ChartAreas[0].AxisX.Title;
                else
                {
                    chartArrivals.Legends.Add(new Legend()
                    {
                        Title = chartArrivals.ChartAreas[0].AxisX.Title,
                        Font = new Font("Segoe UI", 9),
                        TitleFont = new Font("Segoe UI", 10, System.Drawing.FontStyle.Bold),
                        Docking = Docking.Top,
                        Alignment = StringAlignment.Center
                    });
                }
                cbShowValues.IsChecked = true;
            }
            else if (chartType == SeriesChartType.Column)
            {
                foreach (Series s in chartArrivals.Series)
                {
                    s.ChartType = SeriesChartType.Bar;
                    s.ChartType = chartType;
                }
            }
            if (accountingInStatistics == 1) chartArrivals.ChartAreas[0].AxisY.Title = "Количество поступлений";
            else chartArrivals.ChartAreas[0].AxisY.Title = "Затраты на поступления, тыс. руб.";
        }

        private void CmbYear_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ChartInitialization();
        }

        private void ArrivalsSeparation_Click(object sender, RoutedEventArgs e)
        {
            ChartInitialization();
        }

        private void ArrivalsSeparation_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            cbArrivalsSeparation.IsChecked = !cbArrivalsSeparation.IsChecked;
            ArrivalsSeparation_Click(null, null);
        }

        private void ReportType_Click(object sender, RoutedEventArgs e)
        {
            switch (((RadioButton)sender).Name)
            {
                case "rbQuarter":
                    cmbYear.IsEnabled = true;
                    break;
                case "rbMonth":
                    cmbYear.IsEnabled = true;
                    rbBar.IsChecked = true;
                    break;
                case "rbYear":
                    cmbYear.IsEnabled = false;
                    break;
                default:
                    break;
            }
            ChartInitialization();
        }

        private void ReportType_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            RadioButton rb = new RadioButton();
            switch (((TextBlock)sender).Text)
            {
                case "По кварталам":
                    rb = rbQuarter;
                    break;
                case "По месяцам":
                    rb = rbMonth;
                    break;
                case "По годам":
                    rb = rbYear;
                    break;
                default:
                    break;
            }
            rb.IsChecked = true;
            ReportType_Click(rb, null);
        }

        private void ChartType_Click(object sender, RoutedEventArgs e)
        {
            switch (((RadioButton)sender).Name)
            {
                case "rbColumn":
                    cbArrivalsSeparation.IsEnabled = true;
                    ChartInitialization();
                    break;
                case "rbBar":
                    cbArrivalsSeparation.IsEnabled = true;
                    ChartInitialization();
                    break;
                case "rbPie":
                    if ((bool)cbArrivalsSeparation.IsChecked)
                    {
                        MessageBox.Show("При выборе типа диаграммы \"Круговая\", нельзя разделить поступления на виды!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Warning);
                        cbArrivalsSeparation.IsChecked = false;
                    }
                    cbArrivalsSeparation.IsEnabled = false;
                    ChartInitialization();
                    break;
                case "rbLine":
                    cbArrivalsSeparation.IsEnabled = true;
                    ChartInitialization();
                    break;
                default:
                    break;
            }
        }

        private void ChartType_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            RadioButton rb = new RadioButton();
            switch (((TextBlock)sender).Text)
            {
                case "Гистограмма":
                    rb = rbColumn;
                    break;
                case "Линейчатая":
                    rb = rbBar;
                    break;
                case "Круговая":
                    rb = rbPie;
                    break;
                case "График":
                    rb = rbLine;
                    break;
                default:
                    break;
            }
            rb.IsChecked = true;
            ChartType_Click(rb, null);
        }

        private void TxbChartTitle_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txbChartTitle.Text == "" || (bool)cbShowTitle.IsChecked) chartArrivals.Titles.Clear();
            else
            {
                if (chartArrivals.Titles.Count == 0)
                {
                    chartArrivals.Titles.Add(txbChartTitle.Text);
                    chartArrivals.Titles[0].Font = new Font("Segoe UI", 15, System.Drawing.FontStyle.Bold);
                }
                else chartArrivals.Titles[0].Text = txbChartTitle.Text;
            }
        }

        private void AccountingInStatistics_Click(object sender, RoutedEventArgs e)
        {
            ChartInitialization();
        }

        private void AccountingInStatistics_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            TextBlock tb = sender as TextBlock;
            if (tb.Text == "По количеству") rbQuantity.IsChecked = true;
            else rbProfit.IsChecked = true;
            ChartInitialization();
        }

        private void ShowTitle_Click(object sender, RoutedEventArgs e)
        {
            TxbChartTitle_TextChanged(null, null);
        }

        private void ShowTitle_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            cbShowTitle.IsChecked = !cbShowTitle.IsChecked;
            TxbChartTitle_TextChanged(null, null);
        }

        private void ShowValues_Click(object sender, RoutedEventArgs e)
        {
            bool showValues = (bool)cbShowValues.IsChecked;
            foreach (Series s in chartArrivals.Series) s.IsValueShownAsLabel = showValues;
        }

        private void ShowValues_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            cbShowValues.IsChecked = !cbShowValues.IsChecked;
            ShowValues_Click(null, null);
        }

        private void BackColor_Click(object sender, RoutedEventArgs e)
        {
            Color color = cbBackColor.IsChecked == true ? Color.White : Color.Transparent;
            foreach (Series s in chartArrivals.Series) s.LabelBackColor = color;
        }

        private void BackColor_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            cbBackColor.IsChecked = !cbBackColor.IsChecked;
            BackColor_Click(null, null);
        }

        private void CbColourDropDown_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            switch (cbColourDropDown.SelectedIndex)
            {
                case 0:
                    chartArrivals.Palette = ChartColorPalette.BrightPastel;
                    break;
                case 1:
                    chartArrivals.Palette = ChartColorPalette.Berry;
                    break;
                case 2:
                    chartArrivals.Palette = ChartColorPalette.Pastel;
                    break;
                case 3:
                    chartArrivals.Palette = ChartColorPalette.Grayscale;
                    break;
                case 4:
                    chartArrivals.Palette = ChartColorPalette.SemiTransparent;
                    break;
                default:
                    break;
            }
        }

        private void TxbStepIntervalArrivals_PreviewTextInput(object sender, System.Windows.Input.TextCompositionEventArgs e)
        {
            if (!(char.IsDigit(e.Text, 0) || (e.Text == ",") && !txbStepIntervalArrivals.Text.Contains(",") && txbStepIntervalArrivals.Text.Length != 0))
                e.Handled = true;
        }

        private void TxbStepIntervalArrivals_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txbStepIntervalArrivals.Text == "")
            {
                txbStepIntervalArrivals.Text = "0";
                txbStepIntervalArrivals.SelectionStart = txbStepIntervalArrivals.Text.Length;
            }
            if (txbStepIntervalArrivals.Text.Length > 6)
            {
                txbStepIntervalArrivals.Text = txbStepIntervalArrivals.Text.Substring(0, 6);
                txbStepIntervalArrivals.SelectionStart = txbStepIntervalArrivals.Text.Length;
            }
        }
        private void StepIntervalArrivals_Click(object sender, RoutedEventArgs e)
        {
            double step = double.Parse(txbStepIntervalArrivals.Text);
            txbStepIntervalArrivals.Text = step.ToString();
            if (step != 0) chartArrivals.ChartAreas[0].AxisY.Interval = step;
            else chartArrivals.ChartAreas[0].AxisY.Interval = 0;
        }

        private void BtnExportChart_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SaveFileDialog sfd = new SaveFileDialog { Filter = "PNG (*.png)|*.png|JPG (*.jpg)|*.jpg|JPEG (*.jpeg)|*.jpeg", Title = "Выберите путь", FileName = txbChartTitle.Text };
                if (sfd.ShowDialog() == true)
                {
                    Bitmap ChartBmp = new Bitmap(chartArrivals.Size.Width, chartArrivals.Size.Height);
                    Rectangle ChartBounds = new Rectangle(0, 0, chartArrivals.Size.Width, chartArrivals.Size.Height);
                    chartArrivals.DrawToBitmap(ChartBmp, ChartBounds);
                    ChartBmp.Save(sfd.FileName);
                    MessageBox.Show("Изображение диаграммы успешно сохранено!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassHelper.frmObj.Navigate(new PageArrivals());
        }
    }
}
